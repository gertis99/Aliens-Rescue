﻿using UnityEngine;

[System.Serializable]
public class DataToSave
{
    public int coins, horizontalBoosters, verticalBoosters, bombBoosters, colorBombBoosters, actualLevel;

    public DataToSave()
    {
        coins = PlayerInfo.Coins;
        horizontalBoosters = PlayerInfo.HorizontalBoosters;
        verticalBoosters = PlayerInfo.VerticalBoosters;
        bombBoosters = PlayerInfo.BombBoosters;
        colorBombBoosters = PlayerInfo.ColorBombBoosters;
        actualLevel = PlayerInfo.ActualLevel;
    }
}

