using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PlayerInfo
{
    public static int Coins { get; set; }
    public static int HorizontalBoosters { get; set; }
    public static int VerticalBoosters { get; set; }
    public static int BombBoosters { get; set; }
    public static int ColorBombBoosters { get; set; }
    public static int ActualLevel { get; set; }

}
